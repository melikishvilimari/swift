//
//  FormViewController.swift
//  iiiiioooooo
//
//  Created by Cleaner on 2/10/15.
//  Copyright (c) 2015 Cleaner. All rights reserved.
//

import UIKit
import MobileCoreServices
import AssetsLibrary
import CoreLocation


protocol FormViewControllerDelegate {
    func formControllerDidFinish(controller:FormViewController, model:FormModel)
}

class FormViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIPickerViewDataSource, UIPickerViewDelegate {
    
    var delegate: FormViewControllerDelegate?
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtDesc: UITextView!
    var model: FormModel = FormModel()
    let picker = UIImagePickerController()
    
    @IBOutlet weak var categoryPicker: UIPickerView!
    
    @IBOutlet weak var timePicker: UIPickerView!
    let pickerData = ["dinner","drink","desert"]
    
    var pickedData: String?
    var pickedTime: String = "1"
    
    @IBAction func shootPhoto(sender: UIBarButtonItem) {
        picker.delegate = self
        picker.allowsEditing = false
        picker.sourceType = UIImagePickerControllerSourceType.Camera
        picker.cameraCaptureMode = .Photo
        picker.mediaTypes = [kUTTypeImage]
        presentViewController(picker, animated: true, completion: nil)
    }
    
    @IBAction func photoFromLibrary(sender: UIBarButtonItem) {
        picker.allowsEditing = false
        picker.sourceType = .PhotoLibrary
        presentViewController(picker, animated: true, completion: nil)
    }
    
    @IBAction func btnSave(sender: AnyObject) {
        if (delegate != nil) {
            model.Name = txtName.text
            model.Desc = txtDesc.text
            model.Minute = "\(pickedTime)"
            model.Category = pickedData
            delegate!.formControllerDidFinish(self, model: model)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pickedData = pickerData[0]
        picker.delegate = self
        categoryPicker.dataSource = self
        categoryPicker.delegate = self
        
        timePicker.dataSource = self
        timePicker.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if(pickerView.tag == 0) {
            return pickerData.count
        }
        return 120
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String! {
        
        if(pickerView.tag == 0) {
            return pickerData[row]
        }
        return "\(row + 1)"
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if(pickerView.tag == 0) {
            pickedData = pickerData[row]
            println(pickedData)
        }
        else {
            pickedTime = "\(row + 1)"
        }
    }
    
    func pickerView(pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        var titleData = "\(row + 1)"
        if(pickerView.tag == 0) {
            titleData = pickerData[row]
        }
        
        var myTitle = NSAttributedString(string: titleData, attributes: [NSFontAttributeName:UIFont(name: "Georgia", size: 15.0)!,NSForegroundColorAttributeName:UIColor.whiteColor()])
        return myTitle
    }
    
    override func touchesBegan(touches: NSSet, withEvent event: UIEvent) {
        self.view.endEditing(true);
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [NSObject : AnyObject]) {
        
        if picker.sourceType == UIImagePickerControllerSourceType.PhotoLibrary {
            println("come")
            let image = info[UIImagePickerControllerOriginalImage] as UIImage
            let library = ALAssetsLibrary()
            var url: NSURL = info[UIImagePickerControllerReferenceURL] as NSURL
            println(url)
            library.assetForURL(url, resultBlock: { (asset: ALAsset!) -> Void in
                if asset.valueForProperty(ALAssetPropertyLocation) != nil {
                    var lat = (asset.valueForProperty(ALAssetPropertyLocation) as CLLocation!).coordinate.latitude
                    var lng = (asset.valueForProperty(ALAssetPropertyLocation) as CLLocation!).coordinate.longitude
                    self.model.Ltd = "\(lat)"
                    self.model.Lng = "\(lng)"
                    println(lat)
                    println(lng)
                }
                else {
                    println("no location")
                    self.model.Ltd = ""
                    self.model.Lng = ""
                }
                
                }, failureBlock: { (error: NSError!) in println("error")
            })
        }
        
        var chosenImage = info[UIImagePickerControllerOriginalImage] as UIImage
        
        
        let fileManager = NSFileManager.defaultManager()
        var imageData: NSData = UIImagePNGRepresentation(chosenImage)
        let documents = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as String
        let imageName = "\(NSDate()).png"
        let path = documents.stringByAppendingPathComponent(imageName)
        
        fileManager.createFileAtPath(path, contents: imageData, attributes: nil)
        
        model.Image = imageName
        
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: path)!)
        
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        dismissViewControllerAnimated(true, completion: nil)
    }

}
