//
//  CollectionViewCell.swift
//  iiiiioooooo
//
//  Created by Cleaner on 2/18/15.
//  Copyright (c) 2015 Cleaner. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var recipeName: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var minuteLabel: UILabel!
    
}
