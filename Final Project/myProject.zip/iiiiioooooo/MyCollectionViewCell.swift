//
//  MyCollectionViewCell.swift
//  iiiiioooooo
//
//  Created by Admin on 3/1/15.
//  Copyright (c) 2015 Cleaner. All rights reserved.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var recipeName: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var minuteLabel: UILabel!
}
